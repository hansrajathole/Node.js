import React from 'react'
import AppRouter from './Router/Router'
import "./index.css"
const App = () => {
  return (
    <>
      <AppRouter/>
    </>
  )
}

export default App
