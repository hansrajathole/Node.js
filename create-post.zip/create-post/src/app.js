const express = require("express")
const app = express()
const router = require("./routes/index.routes")
const e = require("express")


app.set("view engine","ejs")
app.set("views","./src/views")    
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(express.static("public"))
app.use("/",router)

module.exports = app
